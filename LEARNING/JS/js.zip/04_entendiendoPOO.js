class vehiculo {
    constructor(tipo, ruedas, motor) {
        this.tipo = tipo;
        this.ruedas = ruedas;
        this.motor = motor;
        this.descripcion = `El vehiculo es un/una `
    }
    verInfo() {
        document.write()
    }
}